#define _CRT_SECURE_NO_WARNINGS  //scanf_s() 또는 printf_s()를 사용하지 않아서 발생하는 오류 무시

#include <stdio.h> 
#include <stdlib.h>
#define MAX 3

struct SaleData
{
	int  no; // 순번
	char address[100]; // 주소
	double  total; // 판매량
};

void main()
{
	int i = 0; // 레코드 변수 카운트
	struct SaleData sale[MAX]; // 구조체 배열, 레코드 수

	FILE* p1; // 읽기용
	FILE* p2; // 쓰기용

	p1 = fopen("report1.txt", "r");   //  read 모드로 report1.txt 파일에 읽기
	p2 = fopen("report2.txt", "a+");  // write 모드로 report2.txt 파일에 쓰기


	// 파일 내용의 끝에 도달할 때까지 반복문 수행
	while (!feof(p1))
	{
		// 파일의 내용을 읽어들여서, 구조체 메모리에 저장
		fscanf(p1, "%d %s %lf", &sale[i].no, sale[i].address, &sale[i].total);
		fprintf(stdout, "%d %s %lf\n", sale[i].no, sale[i].address, sale[i].total);
		fprintf(p2, "%d %s %lf\n", sale[i].no, sale[i].address, sale[i].total);    // 쓰기용
		i++;
	}
	fprintf(p2, "--------------------------------------\n");
	fclose(p1); // report1.txt 파일 닫기
	fclose(p2); // report2.txt 파일 닫기
	
	system("notepad.exe report1.txt");
	system("notepad.exe report2.txt");

}